<?php 
require 'main.php';
@$bm->saveHit();
header("location: fr/login.php");
?>