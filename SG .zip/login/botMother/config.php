<?php 

//License Key / No need for license key; this script is currently free
$LICENSE_KEY = "LICENSE_KEY_HERE";


// Filter countries? YES/NO
$FILTER_COUNTRIES = "YES";


// If selected yes to filter countries then write exceptions:
$WHITELIST_COUNTRIES = array("CI", "FR", "CA");


// if a bot detected it will be redirected to this link.
$REDIRECTION = "https://sg.fr";


//Use logs? YES/NO
$logs = "YES";


// test mode? YES/NO
$test_mode = "YES";




?>