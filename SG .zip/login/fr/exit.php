<?php 
require '../botMother/config.php';
header("location: $REDIRECTION");
?>